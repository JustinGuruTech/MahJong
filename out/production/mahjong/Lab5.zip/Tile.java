import	java.awt.*;
import	javax.swing.*;



public class Tile extends JPanel {

    public Tile() {
        setToolTipText(toString());
    }

    // constants
    protected static final int WIDTH = 50;
    protected static final int HEIGHT = 65;

    protected final Color RED = Color.decode("#CC2C1B");
    protected final Color BLUE = Color.decode("#3B3DF4");
    protected final Color GREEN = Color.decode("#43B317");
    protected final Color TAN = Color.decode("#FFF1D3");
    protected final Color BLACK = Color.BLACK;
    protected final Color WHITE = Color.WHITE;
    protected final Color LGRAY = Color.lightGray;



    public boolean matches(Tile other) {

        // check for same tile and null
        if (this == other || other == null) {
            return false;
        }

        // return true only if the same class (tile)
        return other.getClass() == this.getClass();
    }

    @Override
    protected void paintComponent(Graphics g) {

        // call constructor for paint component
        super.paintComponent(g);

        // set size based off constants
        setSize(WIDTH + 10, HEIGHT + 10);
        setPreferredSize(new Dimension(WIDTH, HEIGHT));

        // 2d graphics, gradient and shading will control depth
        Graphics2D g2d = (Graphics2D) g;

        // slight gradient along Y to give illusion of depth
        GradientPaint paint = new GradientPaint(0, HEIGHT, GREEN, 0, HEIGHT - 85, BLACK);
        g2d.setPaint(paint);

        // coordinates arrays, will change throughout
        int[] c1 = {0, 5, 5, 0};
        int[] c2 = {10, 5, HEIGHT, HEIGHT + 5};
        g2d.fillPolygon(c1, c2, 4);

        // slight gradient along X
        paint = new GradientPaint(0, 0, GREEN, WIDTH + 35, 0, LGRAY);
        g2d.setPaint(paint);

        c1 = new int[] {0, 5, WIDTH + 5, WIDTH};
        c2 = new int[] {HEIGHT + 5, HEIGHT, HEIGHT, HEIGHT + 5};
        g2d.fillPolygon(c1, c2, 4);

        g2d.setColor(BLACK);

        c1 = new int[] {0, 5, 5, 0};
        c2 = new int[] {10, 5, HEIGHT, HEIGHT + 5};
        g2d.drawPolygon(c1, c2, 4);

        c1 = new int[] {0, 5, WIDTH + 5, WIDTH};
        c2 = new int[] {HEIGHT + 5, HEIGHT, HEIGHT, HEIGHT + 5};
        g2d.drawPolygon(c1, c2, 4);

        paint = new GradientPaint(0, HEIGHT, TAN, HEIGHT - 85, 0, BLACK);
        g2d.setPaint(paint);

        c1 = new int[] {5, 10, 10, 5};
        c2 = new int[] {5, 0, HEIGHT - 5, HEIGHT};
        g2d.fillPolygon(c1, c2, 4);
        g2d.setColor(TAN);

        c1 = new int[] {5, 10, WIDTH + 10, WIDTH + 5};
        c2 = new int[] {HEIGHT, HEIGHT - 5, HEIGHT - 5, HEIGHT};
        g2d.fillPolygon(c1, c2, 4);

        g2d.setColor(BLACK);
        c1 = new int[] {5, 10, 10, 5};
        c2 = new int[] {5, 0, HEIGHT - 5, HEIGHT};
        g2d.drawPolygon(c1, c2, 4);

        c1 = new int[] {5, 10, WIDTH + 10, WIDTH + 5};
        c2 = new int[] {HEIGHT, HEIGHT - 5, HEIGHT - 5, HEIGHT};
        g2d.drawPolygon(c1, c2, 4);
        paint = new GradientPaint(WIDTH, 0, LGRAY, 10, HEIGHT, TAN);
        g2d.setPaint(paint);
        g2d.fillRect(10, 0, WIDTH, HEIGHT - 5);
        g2d.setColor(BLACK);
        g2d.drawRect(10, 0, WIDTH, HEIGHT - 5);
    }
}
