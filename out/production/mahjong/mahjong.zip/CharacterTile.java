import java.util.*;

public class CharacterTile extends Tile {

    protected char symbol;
    public static HashMap<Character, Character> map = new HashMap<>();
    public static HashMap<Character, String> map2 = new HashMap<>();
    static {
        Character normal[] = {'1', '2', '3', '4', '5', '6', '7', '8', '9', 'N', 'E', 'W', 'S', 'C', 'F'};
        Character chinese[] = {'\u4E00', '\u4E8C', '\u4E09', '\u56DB', '\u4E94', '\u516D', '\u4E03', '\u516B', '\u4E5D', '\u5317', '\u6771', '\u897F', '\u5357', '\u4E2D', '\u767C'};
        for (int i = 0; i < normal.length; i++) {
            map.put(normal[i], chinese[i]);
        }
    }

    public CharacterTile(char symbol) {
        this.symbol = symbol;
    }

    public boolean matches(Tile other) {

        // check for same class
        if (super.matches(other)) {

            // return true only if symbols are equal
            return this.symbol == ((CharacterTile)other).symbol;
        }

        return false;
    }

    public String toString() {

        switch (this.symbol) {
            case 'N':
                return "North Wind";
            case 'E':
                return "East Wind";
            case 'W':
                return "West Wind";
            case 'S':
                return "South Wind";
            case 'C':
                return "Red Dragon";
            case 'F':
                return "Green Dragon";
            default:
                return "Character " + this.symbol;
        }

    }

    public String toChinese() {

        return Character.toString(map.get(this.symbol));
    }
}
