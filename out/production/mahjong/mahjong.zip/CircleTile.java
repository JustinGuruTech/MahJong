public class CircleTile extends RankTile {

    public CircleTile(int rank) {
        super(rank);
    }

    public String toString() {

        return "Circle " + this.rank;
    }
}
