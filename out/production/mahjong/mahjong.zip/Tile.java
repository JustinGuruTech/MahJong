public class Tile {

    public boolean matches(Tile other) {

        // check for same tile and null
        if (this == other || other == null) {
            return false;
        }

        // return true only if the same class (tile)
        return other.getClass() == this.getClass();
    }
}
